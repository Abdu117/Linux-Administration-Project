This file is named hello.c
